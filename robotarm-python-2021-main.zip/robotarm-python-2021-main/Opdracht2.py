from RobotArm import RobotArm

robotArm = RobotArm('exercise 2')

# Jouw python instructies zet je vanaf hier:
robotArm.drop()
robotArm.grab()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.drop()
robotArm.moveLeft()
robotArm.moveLeft()
robotArm.drop()
robotArm.grab()
robotArm.moveRight()
robotArm.moveRight()
robotArm.drop()
robotArm.moveLeft()
robotArm.moveLeft()
robotArm.moveLeft()
robotArm.moveLeft()
robotArm.moveLeft()
robotArm.drop()
robotArm.grab()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.moveRight()
robotArm.drop()




# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()